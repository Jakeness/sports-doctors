<?php

return [
    'googleMapsKey' => 'YOUR_GOOGLE_MAPS_API_KEY',
];