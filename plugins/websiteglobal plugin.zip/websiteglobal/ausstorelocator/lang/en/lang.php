<?php return [
    'plugin' => [
        'name' => 'Aus Store Locator',
        'description' => ''
    ]
];