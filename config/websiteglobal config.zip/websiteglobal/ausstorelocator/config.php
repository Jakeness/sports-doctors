<?php

return [
    'googleMapsKey' => 'AIzaSyCQAYsB_fwTY5I28kdvnPW1IiCO_uUYyvs',
];